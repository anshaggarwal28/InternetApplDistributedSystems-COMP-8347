from django.contrib import admin

# Register your models here.
from django.contrib import admin
from django.db import models
from .models import Category_g5, Course_g5, Students_g5, Instructor_g5, Order
# Register your models here.
admin.site.register(Category_g5)
admin.site.register(Course_g5)
admin.site.register(Students_g5)
admin.site.register(Instructor_g5)
admin.site.register(Order)