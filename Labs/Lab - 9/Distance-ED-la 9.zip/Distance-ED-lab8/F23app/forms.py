from django import forms
from F23app.models import Order
from django.forms import ModelForm
from django.forms.widgets import RadioSelect, SelectDateWidget

class InterestForm(forms.Form):
    INTEREST_CHOICES = [
        (1, 'Yes'),
        (0, 'No'),
    ]

    interested = forms.TypedChoiceField(
        choices=INTEREST_CHOICES,
        widget=forms.RadioSelect,
        coerce=int,
        initial=0
    )

    levels = forms.IntegerField(
        min_value=1,
        initial=1
    )

    comments = forms.CharField(
        widget=forms.Textarea(attrs={'label': 'Additional Comments'}),
        required=False
    )


class OrderForm(ModelForm):

    class Meta:
        model = Order
        fields = ['student', 'course', 'levels', 'order_date']

        widgets = {
            'student': RadioSelect(),
            'order_date': SelectDateWidget()
        }