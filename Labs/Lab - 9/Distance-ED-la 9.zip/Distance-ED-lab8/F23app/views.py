from datetime import datetime

from _decimal import Decimal
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.shortcuts import render, get_object_or_404, redirect
from .forms import OrderForm, InterestForm
from django.contrib import messages

from django.contrib.auth import authenticate, login, logout

from .models import Category_g5, Course_g5, Students_g5, Instructor_g5


def index(request):
    user = request.user
    category_list = Category_g5.objects.all().order_by('id')
    print(category_list)

    # Check if last_login_info exists in session
    if 'last_login_info' in request.session:
        last_login_info = request.session['last_login_info']
    else:
        last_login_info = 'Your last login was more than one hour ago'

    # Check if the 'user_visits' cookie exists
    if 'user_visits' in request.COOKIES:
        # If the cookie exists, retrieve the value and increment by 1
        user_visits = int(request.COOKIES['user_visits']) + 1
    else:
        # If the cookie doesn't exist, set user_visits to 1
        user_visits = 1

    # Store the updated information in a cookie ('user_visits') and set it to expire after 5 minutes
    response = render(request, 'F23app/index.html',
                      {'category_list': category_list, 'user_visits': user_visits, 'last_login_info': last_login_info})
    response.set_cookie('user_visits', user_visits, max_age=300)  # 300 seconds = 5 minutes

    return response


def about(request):
    heading1 = 'This is a Distance Education Website! Search our Categories to find all available Courses.'

    return render(request, 'F23app/about.html', {'heading1': heading1})


def detail(request, category_no):
    category = get_object_or_404(Category_g5, id=category_no)
    courses = Course_g5.objects.filter(categories_g5=category)

    context = {
        'category': category,
        'courses': courses,
    }

    return render(request, 'F23app/detail.html', context)


from django.http import Http404, HttpResponseRedirect, HttpResponse
from django.shortcuts import render


def courses(request):
    courlist = Course_g5.objects.all().order_by('id')

    # Set a test cookie named 'courses_test_cookie'
    response = render(request, 'F23app/courses.html', {'courlist': courlist})
    response.set_cookie('courses_test_cookie', 'cookie_value')

    return response


def instructor_details(request, instructor_id):
    if 'courses_test_cookie' in request.COOKIES:
        # The test cookie worked
        test_cookie_value = request.COOKIES['courses_test_cookie']
        # Do something with the actual cookie value if needed

        # Delete the test cookie
        response = render(request, 'F23app/instructor_details.html', {'test_cookie_value': test_cookie_value})
        response.delete_cookie('courses_test_cookie')
    else:
        test_cookie_value = None  # Handle the case where the cookie is not present
        response = render(request, 'F23app/instructor_details.html', {'test_cookie_value': test_cookie_value})

        # Use get_object_or_404 to retrieve the instructor or raise a 404 error if not found
    instructor = get_object_or_404(Instructor_g5, pk=instructor_id)

    # Retrieve related data, such as courses and students
    courses_taught = instructor.course_g5_set.all()
    students = instructor.student_relationship_g5.all()

    context = {
        'instructor': instructor,
        'courses_taught': courses_taught,
        'students': students,
    }

    return response


def place_order(request):
    msg = ''
    courlist = Course_g5.objects.all()

    if request.method == 'POST':
        form = OrderForm(request.POST)

        if form.is_valid():
            order = form.save(commit=False)  # Do not save to the database yet, so we can make additional checks

            # Check if the ordered levels exceed the maximum levels for the course
            if order.levels > order.course.max_levels:
                msg = f'The number of levels ordered exceeds the maximum allowed for {order.course.title_g5}.'
                order.order_status = 1  # Order Cancelled
            else:
                msg = 'Your course has been ordered successfully.'
                # Set order_price before saving
                order.order_price = order.course.price_g5
                # Check if the course price is greater than $150.00
                if order.course.price_g5 > Decimal('150.00'):
                    order.discount()  # Call the discount method to update the price

                order.order_status = 0  # Order Confirmed
                order.save()  # Save the order now

        else:
            msg = 'There was an issue with your order. Please check the form and try again.'

        return render(request, 'F23app/order_response.html', {'msg': msg})

    else:
        form = OrderForm()

    return render(request, 'F23app/place_order.html', {'form': form, 'msg': msg, 'courlist': courlist})


def coursedetail(request, course_id):
    course = get_object_or_404(Course_g5, pk=course_id)
    interested_form = InterestForm()

    if request.method == 'POST':
        interested_form = InterestForm(request.POST)
        if interested_form.is_valid():
            interested_value = interested_form.cleaned_data['interested']

            # If interested is 1, increment the interested field for the course
            if interested_value == 1:
                course.interested += 1
                course.save()

                # Redirect to the main index page
                return redirect('index')

    return render(request, 'F23app/coursedetail.html', {'course': course, 'interested_form': interested_form})


from django.contrib.auth import authenticate, login
from django.http import HttpResponse
from django.shortcuts import render
from django.utils import timezone


def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)

        if user:
            if user.is_active:
                # Log in the user
                login(request, user)

                # Generate the date and time of the current login
                current_login_time = timezone.now()

                # Store this value as a session parameter (last_login_info)
                request.session['last_login_info'] = current_login_time.isoformat()

                # Set the session to expire when the browser is closed
                # request.session.set_expiry(3600)
                request.session.set_expiry(0)

                return redirect('index')
            else:
                return HttpResponse('Your account is disabled.')
        else:
            return HttpResponse('Invalid login details.')
    else:
        # Render the login form
        return render(request, 'F23app/login.html')


@login_required
def logout_user(request):
    # Delete the user-related session data
    if 'last_login_info' in request.session:
        del request.session['last_login_info']

    # Add a success message
    messages.success(request, "Logged out successfully.")

    # Redirect to the index page
    return redirect('index')


from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Students_g5, Order


@login_required
def myaccount(request):
    user = request.user
    print(user)
    if hasattr(user, 'student_user'):
        # User is a Student
        student = user.student_user

        # Retrieve courses ordered by the student
        ordered_courses = Order.objects.filter(student=student)

        # Retrieve courses the student is interested in
        interested_courses = student.course_g5_set.all()

        context = {
            'full_name': f"{student.first_name_g5} {student.last_name_g5}",
            'ordered_courses': ordered_courses,
            'interested_courses': interested_courses,
            'is_student': True,
        }

        return render(request, 'F23app/myaccount.html', context)
    else:
        # User is not a student
        context = {
            'is_student': False,
            'message': 'You are not a registered student!',
        }

        return render(request, 'F23app/myaccount.html', context)
