from django.apps import AppConfig


class F23AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'F23app'
