from _decimal import Decimal
from django.contrib.auth.models import AbstractUser, User
from django.core.validators import MinValueValidator
from django.db import models

# Create your models here.
from django.db import models

from django.db import models


# models.py
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.db import models
from django.utils import timezone


class Students_g5(models.Model):
    STUDENT_STATUS_CHOICES_G5 = [
        ('ER', 'Enrolled'), ('SP', 'Suspended'), ('GD', 'Graduated')]

    first_name_g5 = models.CharField(max_length=50)
    last_name_g5 = models.CharField(max_length=20)
    email_g5 = models.EmailField(unique=True)
    dob_g5 = models.DateField()
    status_g5 = models.CharField(max_length=10, choices=STUDENT_STATUS_CHOICES_G5, default='enrolled')
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='student_user', default='')


    def __str__(self):
        return f"{self.first_name_g5} {self.last_name_g5}"



class Category_g5(models.Model):  # DECLARING A CLASS NAMED Category_g5 THAT IS INHERITING models.Model INDICATING Django MODEL CLASS
    name_g5 = models.CharField(max_length=50)  # CREATING CHARACTER FIELD OF LENGTH 50 HERE

    def __str__(self):  # THIS WILL PRINT THE STR REPRESENTATION OF OBJECT
        return self.name_g5  # Category_G5 SHOULD BE REPRESENTED BY VALUE OF name_g5


class Instructor_g5(models.Model):
    first_name_g5 = models.CharField(max_length=50)
    last_name_g5 = models.CharField(max_length=20)
    instructor_bio_g5 = models.TextField(max_length=1000)
    # course_relationship_g5 = models.OneToOneField()
    student_relationship_g5 = models.ManyToManyField(Students_g5)

    def __str__(self):
        return f"{self.first_name_g5} {self.last_name_g5}"


# models.py
from decimal import Decimal
from django.db import models
from django.core.validators import MinValueValidator
from django.forms import ModelForm, RadioSelect, SelectDateWidget

class Course_g5(models.Model):
    title_g5 = models.CharField(max_length=200)
    description_g5 = models.TextField()
    instructor_g5 = models.ForeignKey(Instructor_g5, on_delete=models.CASCADE)
    categories_g5 = models.ForeignKey(Category_g5, on_delete=models.CASCADE)
    students_g5 = models.ManyToManyField(Students_g5, blank=True)
    start_date_g5 = models.DateField()
    end_date_g5 = models.DateField()
    price_g5 = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    interested = models.PositiveIntegerField(default=0, validators=[MinValueValidator(0)])
    COURSE_LEVEL_CHOICES_G5 = [
        ('BE', 'Beginner'),
        ('IN', 'Intermediate'),
        ('AD', 'Advanced')
    ]
    level_g5 = models.CharField(max_length=2, choices=COURSE_LEVEL_CHOICES_G5, default='BE')
    max_levels = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1)])

    def __str__(self):
        return f"{self.title_g5} {self.instructor_g5} {self.level_g5}"

class Order(models.Model):
    ORDER_STATUS_CHOICES = [
        (0, 'Order Confirmed'),
        (1, 'Order Cancelled'),
    ]

    course = models.ForeignKey(Course_g5, on_delete=models.CASCADE)
    student = models.ForeignKey(Students_g5, on_delete=models.CASCADE)
    order_status = models.IntegerField(choices=ORDER_STATUS_CHOICES, default=1)
    order_date = models.DateField()
    order_price = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    levels = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1)])

    def discount(self):
        discount_value = Decimal('0.1')  # Use Decimal for precision
        self.order_price -= self.order_price * discount_value
        self.save()

    def __str__(self):
        return f'Order for {self.student} - Status: {self.get_order_status_display()}'
